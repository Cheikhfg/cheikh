from django.contrib import admin
from .models import Rating

admin.site.register(Rating)
